# EVOLVE-BLOCK-START
"""Function minimization example for OpenEvolve"""
import numpy as np


def search_algorithm(iterations=1000, bounds=(-5, 5)):
    """
    An improved search algorithm combining global exploration with adaptive local exploitation,
    and mechanisms to escape local minima.

    Args:
        iterations: Number of iterations to run
        bounds: Bounds for the search space (min, max)

    Returns:
        Tuple of (best_x, best_y, best_value)
    """
    low, high = bounds
    best_x = np.random.uniform(low, high)
    best_y = np.random.uniform(low, high)
    best_value = evaluate_function(best_x, best_y)

    total_range = high - low

    # Parameters for adaptive search strategy
    initial_explore_prob = 0.7  # Start with high global exploration
    min_explore_prob = 0.05     # Minimum global exploration probability
    initial_local_std = total_range / 5.0 # Initial standard deviation for local search
    min_local_std = 1e-4        # Minimum standard deviation to prevent stagnation
    decay_exponent = 2.0        # Controls how fast exploration/step size decays (higher means faster decay)

    # Parameters for escaping local minima
    no_improvement_streak_limit = iterations // 20 # Trigger reset if no improvement for 5% of iterations
    large_jump_factor = 2.0     # Factor to increase local std for a large jump
    force_global_jump_prob = 0.5 # Probability of a full global jump when stuck

    no_improvement_streak = 0

    for i in range(iterations):
        # Calculate current exploration probability and local search standard deviation
        # Decay factor ensures more exploration early and more exploitation later
        progress = i / iterations
        decay_factor = (1.0 - progress)**decay_exponent

        current_explore_prob = max(min_explore_prob, initial_explore_prob * decay_factor)
        current_local_std = max(min_local_std, initial_local_std * decay_factor)

        x_candidate, y_candidate = best_x, best_y # Initialize candidate with current best

        perform_escape_attempt = False
        if no_improvement_streak >= no_improvement_streak_limit:
            perform_escape_attempt = True
            no_improvement_streak = 0 # Reset streak after triggering an escape attempt

        if perform_escape_attempt:
            if np.random.rand() < force_global_jump_prob:
                # Perform a full global jump
                x_candidate = np.random.uniform(low, high)
                y_candidate = np.random.uniform(low, high)
            else:
                # Perform a wider local jump around the current best
                temp_local_std = current_local_std * large_jump_factor
                x_candidate = np.random.normal(loc=best_x, scale=temp_local_std)
                y_candidate = np.random.normal(loc=best_y, scale=temp_local_std)
        elif np.random.rand() < current_explore_prob:
            # Regular global exploration
            x_candidate = np.random.uniform(low, high)
            y_candidate = np.random.uniform(low, high)
        else:
            # Local exploitation: perturb the current best point using a normal distribution
            x_candidate = np.random.normal(loc=best_x, scale=current_local_std)
            y_candidate = np.random.normal(loc=best_y, scale=current_local_std)

        # Clip candidate coordinates to stay within the defined bounds
        x_candidate = np.clip(x_candidate, low, high)
        y_candidate = np.clip(y_candidate, low, high)

        value = evaluate_function(x_candidate, y_candidate)

        if value < best_value:
            best_value = value
            best_x, best_y = x_candidate, y_candidate
            no_improvement_streak = 0 # Reset streak on improvement
        else:
            no_improvement_streak += 1 # Increment streak if no improvement

    return best_x, best_y, best_value


# EVOLVE-BLOCK-END


# This part remains fixed (not evolved)
def evaluate_function(x, y):
    """The complex function we're trying to minimize"""
    return np.sin(x) * np.cos(y) + np.sin(x * y) + (x**2 + y**2) / 20


def run_search():
    x, y, value = search_algorithm()
    return x, y, value


if __name__ == "__main__":
    x, y, value = run_search()
    print(f"Found minimum at ({x}, {y}) with value {value}")
